<?php
$_['heading_title'] = 'Recent Articles';

$_['date_format']      = 'M d, Y';
$_['date_time_format']   = 'M d, Y h:i a';
?>