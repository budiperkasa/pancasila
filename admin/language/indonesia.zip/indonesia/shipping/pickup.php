<?php
// Heading
$_['heading_title']= 'Pickup dari Toko';

// Teks 
$_['text_shipping']= 'Pengiriman';
$_['text_success'] = 'Berhasil: Anda berhasil mengubah pickup dari Toko!';

// Entry
$_['entry_geo_zone'] = 'Zona Geo:';
$_['entry_status'] = 'Status:';
$_['entry_sort_order'] = 'Urutan Pengurutan:';

// Error
$_['error_permission'] = 'Peringatan: Anda tidak memiliki wewenang untuk mengubah pickup dari Toko!';
?>