<?php
// Heading
$_['heading_title']= 'Pengiriman Gratis';

// Teks 
$_['text_shipping']= 'Pengiriman';
$_['text_success'] = 'Berhasil: Anda berhasil mengubah Gratis Pengiriman!';

// Entry
$_['entry_total']= 'Total:<br /><span class="help">Jumlah belanja minimum yang diperlukan untuk Gratis Pengiriman.</span>';
$_['entry_geo_zone'] = 'Zona Geografis:';
$_['entry_status'] = 'Status:';
$_['entry_sort_order'] = 'Urutan Posisi:';

// Error
$_['error_permission'] = 'Peringatan: Anda tidak memiliki wewenang untuk mengubah Gratis Pengiriman!';
?>