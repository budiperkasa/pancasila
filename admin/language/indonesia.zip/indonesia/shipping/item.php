<?php 
// Heading
$_['heading_title'] = 'Per Item';

// Teks
$_['text_shipping']= 'Pengiriman';
$_['text_success'] = 'Berhasil: Anda berhasil mengubah Pengiriman per item rates!';

// Entry
$_['entry_cost'] = 'Biaya:';
$_['entry_tax_class']= 'Golongan Pajak:';
$_['entry_geo_zone'] = 'Zona Geo:';
$_['entry_status'] = 'Status:';
$_['entry_sort_order'] = 'Urutan Pengurutan:';

// Error
$_['error_permission'] = 'Peringatan: Anda tidak memiliki wewenang untuk mengubah Pengiriman per item rates!';
?>