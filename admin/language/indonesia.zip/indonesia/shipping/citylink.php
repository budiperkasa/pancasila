<?php
// Heading
$_['heading_title']= 'Citylink';

// Teks
$_['text_shipping']= 'Pengiriman';
$_['text_success'] = 'Berhasil: Anda berhasil mengubah Pengiriman Citylink !';

// Entry
$_['entry_rate'] = 'Citylink Rates:<br /><span class="help">masukkan nilai hingga sejumlah 5,2 Desimal. (12345.67) Contoh: .1:1,.25:1.27 - Weights less than atau equal to 0.1Kg would Biaya &pound;1.00, Weights less than atau equal to 0.25g but more than 0.1Kg will Biaya 1.27. Do not enter KG atau symbols.</span>';
$_['entry_tax_class']= 'Golongan Pajak:';
$_['entry_geo_zone'] = 'Zona Geo:';
$_['entry_status'] = 'Status:';
$_['entry_sort_order'] = 'Urutan Pengurutan:';

// Error
$_['error_permission'] = 'Peringatan: Anda tidak memiliki wewenang untuk mengubah Pengiriman Citylink !';
?>