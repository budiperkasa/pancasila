<?php
// Heading
$_['heading_title'] = 'Selamat Datang';

// Teks
$_['text_module'] = 'Modul';
$_['text_success']= 'Berhasil: Anda berhasil mengubah modul Selamat Datang!';
$_['text_content_top']= 'Content Top - Atas';
$_['text_content_bottom'] = 'Content Bottom - Bawah';
$_['text_column_left']= 'Column Left - Kiri';
$_['text_column_right'] = 'Column Right - kanan';

// Entry
$_['entry_description'] = 'Selamat Datang Pesan:';
$_['entry_layout']= 'Layout:';
$_['entry_position']= 'Posisi:';
$_['entry_status']= 'Status:';
$_['entry_sort_order']= 'Urutan Pengurutan:';

// Error
$_['error_permission']= 'Peringatan: Anda tidak memiliki wewenang untuk mengubah modul Selamat Datang!';
?>