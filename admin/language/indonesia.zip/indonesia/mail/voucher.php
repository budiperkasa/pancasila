<?php
// Teks
$_['text_subject']= 'Voucher Hadiah dari %s';
$_['text_greeting'] = 'Selamat, Anda telah menerima sebuah Voucher Hadiah senilai %s.';
$_['text_from'] = 'Voucher tersebut dikirim oleh %s.';
$_['text_message']= 'dengan pesan:';
$_['text_redeem'] = 'Untuk memanfaatkan Voucher Hadiah tersebut, catat kode Voucher yaitu <b>%s</b> lalu klik link di bawah ini dan belilah produk yang Anda inginkan dengan menggunakan Voucher. Anda bisa memasukkan kode Voucher Hadiah tersebut di halaman keranjang belanja sebelum menuju kasir.';
$_['text_footer'] = 'Jika ada hal-hal yang ingin Anda tanyakan, silakan membalas email ini. Petugas kami akan melayani Anda dengan senang hati.';
?>