<?php
// Teks
$_['text_subject']= '%s - Pemberitahuan tentang Order %s';
$_['text_order']= 'No. Order:';
$_['text_date_added'] = 'Tanggal Order:';
$_['text_order_status'] = 'Order Anda telah diperbarui dengan status berikut ini:';
$_['text_comment']= 'Catatan untuk order Anda:';
$_['text_link'] = 'Untuk melihat order Anda klik link di bawah ini:';
$_['text_footer'] = 'Silahkan balas email ini jika Anda memiliki pertanyaan. Terima kasih.';
?>