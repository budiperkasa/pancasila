<?php
// Teks
$_['text_subject']= '%s - Minta Reset Password';
$_['text_greeting'] = 'Kami telah menerima permintaan reset password atas nama Anda.';
$_['text_change'] = 'Untuk mereset password tersebut, klik link di bawah ini:';
$_['text_ip'] = 'IP yang digunakan untuk meminta password baru adalah %s. Mohon abaikan email ini apabila Anda tidak pernah meminta reset password.';
?>