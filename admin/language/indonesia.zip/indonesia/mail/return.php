<?php
// Teks
$_['text_subject']       = '%s - Pemberitahuan tentang Retur %s';
$_['text_return_id']     = 'No. Retur:';
$_['text_date_added']    = 'Tanggal Retur:';
$_['text_return_status'] = 'Retur Anda telah diperbarui dengan status berikut ini:';
$_['text_comment']       = 'Catatan untuk Retur Anda:';
$_['text_footer']        = 'Silahkan balas email ini jika Anda memiliki pertanyaan. Terima kasih.';
?>