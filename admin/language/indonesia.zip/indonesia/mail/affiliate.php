<?php
// Teks
$_['text_approve_subject']= '%s - Akun Reseller Anda sudah disetujui!';
$_['text_approve_welcome']= 'Selamat dan terima kasih telah bergabung di program Reseller %s!';
$_['text_approve_login']= 'Akun Anda sudah disetujui dan Anda sudah bisa melakukan login dengan menggunakan alamat email dan password yang Anda daftarkan untuk program Reseller, dengan mengunjungi website atau URL berikut ini:';
$_['text_approve_services'] = 'Dengan melakukan login, Anda dapat membuat kode pelacakan, melacak pembayaran komisi, dan mengubah informasi akun Anda. Pembayaran komisi dijadwalkan setiap akhir triwulan.';
$_['text_approve_thanks'] = 'Terima kasih,';
$_['text_transaction_subject']= '%s - Komisi Reseller';
$_['text_transaction_received'] = 'Anda telah menerima komisi sebanyak %s !';
$_['text_transaction_total']= 'Jumlah total komisi Anda sekarang : %s.';
?>