<?php
// Heading
$_['heading_title']= 'Total';

// Teks
$_['text_total'] = 'Total Pesanan';
$_['text_success'] = 'Berhasil: Anda berhasil mengubah total total pesanan!';

// Entry
$_['entry_status'] = 'Status:';
$_['entry_sort_order'] = 'Urutan Posisi:';

// Error
$_['error_permission'] = 'Peringatan: Anda tidak memiliki wewenang untuk mengubah total total! pesanan';
?>