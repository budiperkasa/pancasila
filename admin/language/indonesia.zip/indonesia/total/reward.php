<?php
// Heading
$_['heading_title']= 'Point hadiah';

// Teks
$_['text_total'] = 'Total Pesanan';
$_['text_success'] = 'Berhasil: Anda berhasil mengubah Total Point hadiah!';

// Entry
$_['entry_status'] = 'Status:';
$_['entry_sort_order'] = 'Urutan Pengurutan:';

// Error
$_['error_permission'] = 'Peringatan: Anda tidak memiliki wewenang untuk mengubah Total Point hadiah!';
?>