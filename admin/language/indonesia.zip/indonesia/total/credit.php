<?php
// Heading
$_['heading_title']= 'Kredit Toko';

// Teks
$_['text_total'] = 'Total Pesanan';
$_['text_success'] = 'Berhasil: Anda berhasil mengubah Kredit Toko!';

// Entry
$_['entry_status'] = 'Status:';
$_['entry_sort_order'] = 'Urutan Posisi:';

// Error
$_['error_permission'] = 'Peringatan: Anda tidak memiliki wewenang untuk mengubah Kredit Toko!';
?>