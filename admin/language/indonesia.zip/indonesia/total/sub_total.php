<?php
// Heading
$_['heading_title']= 'Sub-Total';

// Teks
$_['text_total'] = 'Total Pesanan';
$_['text_success'] = 'Berhasil: Anda berhasil mengubah Total sub-total!';

// Entry
$_['entry_status'] = 'Status:';
$_['entry_sort_order'] = 'Urutan Pengurutan:';

// Error
$_['error_permission'] = 'Peringatan: Anda tidak memiliki wewenang untuk mengubah Total sub-total!';
?>