<?php
// Heading
$_['heading_title']= 'Low Order Fee';

// Teks
$_['text_total'] = 'Total Pesanan';
$_['text_success'] = 'Berhasil: Anda berhasil mengubah low Total order fee!';

// Entry
$_['entry_total']= 'Order Total:';
$_['entry_fee']= 'Fee:';
$_['entry_tax_class']= 'Golongan Pajak:';
$_['entry_status'] = 'Status:';
$_['entry_sort_order'] = 'Urutan Pengurutan:';

// Error
$_['error_permission'] = 'Peringatan: Anda tidak memiliki wewenang untuk mengubah low Total order fee!';
?>