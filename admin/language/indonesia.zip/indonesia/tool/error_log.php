<?php
// Heading
$_['heading_title'] = 'Error Log';

// Teks
$_['text_success']= 'Berhasil: Anda telah berhasil cleared your error log!';
?>