<?php
// Heading
$_['heading_title']= 'Backup / Restore';

// Teks
$_['text_backup']= 'Download Backup';
$_['text_success'] = 'Berhasil: Anda telah berhasil meng-import database anda!';

// Entry
$_['entry_restore']= 'Restore Backup:';
$_['entry_backup'] = 'Backup:';

// Error
$_['error_permission'] = 'Peringatan: Anda tidak memiliki wewenang untuk mengubah backups!';
$_['error_empty']= 'Peringatan: File yang anda upload tidak ada!';
?>