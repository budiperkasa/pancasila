<?php
// Text
$_['text_title'] = 'Kredit Card / Debit Card (AsiaPay)';
?>