<?php
// Heading
$_['heading_title']= 'Gratis Checkout';

// Teks
$_['text_payment'] = 'Pembayaran';
$_['text_success'] = 'Berhasil: Anda berhasil mengubah modul Pembayaran Gratis Checkout !';

// Entry
$_['entry_order_status'] = 'Nama Status Pesanan:';
$_['entry_status'] = 'Status:';
$_['entry_sort_order'] = 'Urutan Pengurutan:';

// Error
$_['error_permission'] = 'Peringatan: Anda tidak memiliki wewenang untuk mengubah Pembayaran Gratis Checkout!';
?>