<?php
// Heading
$_['heading_title'] = 'Pengiriman';

// Teks
$_['text_install']= 'Install';
$_['text_uninstall']= 'Uninstall';

// Column
$_['column_name'] = 'Metode Pengiriman';
$_['column_status'] = 'Status';
$_['column_sort_order'] = 'Urutan Posisi';
$_['column_action'] = 'Tindakan';

// Error
$_['error_permission']= 'Peringatan: Anda tidak memiliki wewenang untuk mengubah Pengiriman!';
?>