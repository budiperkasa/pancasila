<?php
// Heading
$_['heading_title']= 'Modul';

// Teks
$_['text_install'] = 'Install';
$_['text_uninstall'] = 'Uninstall';

// Column
$_['column_name']= 'Nama Modul';
$_['column_action']= 'Tindakan';

// Error
$_['error_permission'] = 'Peringatan: Anda tidak memiliki wewenang untuk mengubah Modul!';
?>