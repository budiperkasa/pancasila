<?php
// Heading
$_['heading_title']= 'Google Sitemap';

// Teks 
$_['text_feed']= 'Product Feeds';
$_['text_success'] = 'Berhasil: Anda berhasil mengubah Google Sitemap feed!';

// Entry
$_['entry_status'] = 'Status:';
$_['entry_data_feed']= 'Data Feed Url:';

// Error
$_['error_permission'] = 'Peringatan: Anda tidak memiliki wewenang untuk mengubah Google Sitemap feed!';
?>