<?php
// Heading
$_['heading_title']= 'Google Base';

// Teks 
$_['text_feed']= 'Product Feeds';
$_['text_success'] = 'Berhasil: Anda berhasil mengubah Google Base feed!';

// Entry
$_['entry_status'] = 'Status:';
$_['entry_data_feed']= 'Data Feed Url:';

// Error
$_['error_permission'] = 'Peringatan: Anda tidak memiliki wewenang untuk mengubah Google Base feed!';
?>