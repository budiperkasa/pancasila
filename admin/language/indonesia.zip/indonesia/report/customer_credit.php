<?php
// Heading
$_['heading_title'] = 'Laporan Kredit Pelanggan ';

// Column
$_['column_customer'] = 'Nama Pelanggan';
$_['column_email']= 'Email';
$_['column_customer_group'] = 'Grup Pelanggan';
$_['column_status'] = 'Status';
$_['column_total']= 'Total';
$_['column_action'] = 'Tindakan';

// Entry
$_['entry_date_start']= 'Tanggal Awal:';
$_['entry_date_end']= 'Tanggal Akhir:';
?>