<?php
// Heading
$_['heading_title'] = 'Laporan Pesanan Pelanggan';

// Teks
$_['text_all_status'] = 'Seluruh status';

// Column
$_['column_customer'] = 'Nama Pelanggan';
$_['column_email']= 'Email';
$_['column_customer_group'] = 'Grup Pelanggan';
$_['column_status'] = 'Status';
$_['column_orders'] = 'Jumlah Pesanan';
$_['column_products'] = 'Jumlah Produk';
$_['column_total']= 'Total';
$_['column_action'] = 'Tindakan';

// Entry
$_['entry_date_start']= 'Tanggal Awal:';
$_['entry_date_end']= 'Tanggal Akhir:';
$_['entry_status']= 'Nama Status Pesanan:';
?>