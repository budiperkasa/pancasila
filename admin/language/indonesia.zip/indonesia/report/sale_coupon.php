<?php
// Heading
$_['heading_title']= 'Laporan Kupon';

// Column
$_['column_name']= 'Nama Kupon';
$_['column_code']= 'Kode';
$_['column_orders']= 'Pesanan';
$_['column_total'] = 'Total';
$_['column_action']= 'Tindakan';

// Entry
$_['entry_date_start'] = 'Tanggal Awal:';
$_['entry_date_end'] = 'Tanggal Akhir:';
?>