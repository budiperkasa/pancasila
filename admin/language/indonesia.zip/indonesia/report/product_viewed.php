<?php
// Heading
$_['heading_title']= 'Laporan Produk yang Dilihat';

// Teks
$_['text_success'] = 'Berhasil: Anda telah mengatur ulang Laporan Produk yang Dilihat!';

// Column
$_['column_name']= 'Nama Produk';
$_['column_model'] = 'Model';
$_['column_viewed']= 'Dilihat';
$_['column_percent'] = 'Persentase';
?>