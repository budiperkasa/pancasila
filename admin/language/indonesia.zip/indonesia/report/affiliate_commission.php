<?php
// Heading
$_['heading_title'] = 'Laporan Komisi Reseller';

// Column
$_['column_Affiliasi']= 'Nama Reseller';
$_['column_email']= 'Email';
$_['column_status'] = 'Status';
$_['column_commission'] = 'Komisi';
$_['column_orders'] = 'Jumlah Pesanan';
$_['column_total']= 'Total';
$_['column_action'] = 'Tindakan';

// Entry
$_['entry_date_start']= 'Tanggal Awal:';
$_['entry_date_end']= 'Tanggal Akhir:';
?>