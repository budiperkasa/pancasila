<?php
// Heading
$_['heading_title'] = 'Maintenance';

// Text
$_['text_maintenance'] = 'Maintenance';
$_['text_Pesan'] = '<h1 style="text-align:center;">Kami sedang melakukan perawatan sistem. <br/>Kami akan kembali sesegera mungkin. Silahkan kembali beberapa saat lagi.</h1>';
?>