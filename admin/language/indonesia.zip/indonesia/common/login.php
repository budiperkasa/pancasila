<?php
// header
$_['heading_title']= 'Administrasi';

// Text
$_['text_heading'] = 'Administrasi';
$_['text_login'] = 'Masukkan detail login Anda.';
$_['text_forgotten'] = 'Lupa Password';

// Entry
$_['entry_username'] = 'Username:';
$_['entry_password'] = 'Password:';

// Button
$_['button_login'] = 'Login';

// Error
$_['error_login']= 'Username and/atau password tidak cocok.';
$_['error_token']= 'Token sudah tidak berlaku. Silakan login kembali.';
?>
