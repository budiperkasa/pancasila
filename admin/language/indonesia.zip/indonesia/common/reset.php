<?php
// header
$_['heading_title']= 'Reset password Anda';

// Text
$_['text_reset'] = 'Reset password Anda!';
$_['text_password']= 'Masukkan password baru yang Anda inginkan.';
$_['text_success'] = 'Berhasil: Password Anda berhasil diperbarui.';

// Entry
$_['entry_password'] = 'Password:';
$_['entry_confirm']= 'Konfirmasi Password:';

// Error
$_['error_password'] = 'Password harus terdiri atas 5 hingga 20 karakter!';
$_['error_confirm']= 'Password dan konfirmasi password tidak cocok!';
?>