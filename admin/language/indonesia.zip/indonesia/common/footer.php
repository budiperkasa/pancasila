<?php
// Text
$_['text_footer'] = '<a href="http://www.busana.com">Busana.com</a> &copy; 2002-' . Date('Y') . ' Hak Cipta Dilindungi Undang-Undang.<br />Versi %s';
?>