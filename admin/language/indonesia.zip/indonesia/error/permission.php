<?php
// Heading
$_['heading_title'] = 'Tidak diperbolehkan!'; 

// Teks
$_['text_permission'] = 'Anda tidak diperbolehkan untuk mengakses halaman ini, silahkan menghubungi administrator sistem Anda.';
?>
