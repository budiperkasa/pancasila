<?php
// Heading
$_['heading_title']= 'Status Stok';

// Teks
$_['text_success'] = 'Berhasil: Anda berhasil mengubah Status Stok!';

// Column
$_['column_name']= 'Nama Status Stok';
$_['column_action']= 'Action';

// Entry
$_['entry_name'] = 'Nama Status Stok:';

// Error
$_['error_permission'] = 'Peringatan: Anda tidak memiliki wewenang untuk mengubah Status Stok!';
$_['error_name'] = 'Nama Status Stok harus terdiri atas 3 hingga 32 karakter!';
$_['error_product']= 'Peringatan:Status Stok ini tidak dapat dihapus karena sedang digunakan pada %s Produk!';
?>
