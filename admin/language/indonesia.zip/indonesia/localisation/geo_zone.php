<?php
// Heading
$_['heading_title']= 'zona geo';

// Teks
$_['text_success'] = 'Berhasil: Anda berhasil mengubah zona geo!';

// Column
$_['column_name']= 'Nama Zona Geo ';
$_['column_description'] = 'Deskripsi';
$_['column_action']= 'Action';

// Entry
$_['entry_name'] = 'Nama Zona Geo :';
$_['entry_description']= 'Deskripsi:';
$_['entry_country']= 'Negara:';
$_['entry_zone'] = 'Zona:';

// Error
$_['error_permission'] = 'Peringatan: Anda tidak memiliki wewenang untuk mengubah zona geo!';
$_['error_name'] = 'Nama Zona Geo harus terdiri atas 3 hingga 32 karakter!';
$_['error_description']= 'Nama Deskripsi harus terdiri atas 3 hingga 255 karakter!';
$_['error_tax_rate'] = 'Peringatan:Zona Geo ini tidak dapat dihapus karena sedang digunakan pada satu atau lebih tingkat bunga pajak!';
?>