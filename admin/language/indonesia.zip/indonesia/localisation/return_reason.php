<?php
// Heading
$_['heading_title']= 'Alasan Retur';

// Teks
$_['text_success'] = 'Berhasil: Anda berhasil mengubah Alasan Retur!';

// Column
$_['column_name']= 'Nama Alasan Retur';
$_['column_action']= 'Tindakan';

// Entry
$_['entry_name'] = 'Nama Alasan Retur:';

// Error
$_['error_permission'] = 'Peringatan: Anda tidak memiliki wewenang untuk mengubah Alasan Retur!';
$_['error_name'] = 'Nama Alasan Retur harus terdiri atas 3 hingga 32 karakter!';
$_['error_return'] = 'Peringatan: Alasan Retur ini tidak dapat dihapus karena sedang digunakan pada %s produk yang dikembalikan!';
?>