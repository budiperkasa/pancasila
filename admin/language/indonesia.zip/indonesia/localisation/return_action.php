<?php
// Heading
$_['heading_title']= 'Tindakan atas Retur;

// Teks
$_['text_success'] = 'Berhasil: Anda berhasil mengubah tindakan atas Retur!';

// Column
$_['column_name']= 'Nama Tindakan atas Retur;
$_['column_action']= 'Tindakann';

// Entry
$_['entry_name'] = 'Nama Tindakan atas Retur:';

// Error
$_['error_permission'] = 'Peringatan: Anda tidak memiliki wewenang untuk mengubah tindakan atas Retur!';
$_['error_name'] = 'Nama Tindakan atas Retur harus terdiri atas 3 hingga 32 karakter!';
$_['error_return'] = 'Peringatan: Tindakan atas Retur ini tidak dapat dihapus karena sedang digunakan pada %s produk yang dikembalikan!';
?>