<?php
// Heading
$_['heading_title']       = 'YM Indicator';

// Text
$_['text_module']         = 'Module';
$_['text_success']        = 'Anda telah berhasil memodifikasi YM Indicator!';
$_['text_content_top']    = 'Content Top';
$_['text_content_bottom'] = 'Content Bottom';
$_['text_column_left']    = 'Column Left';
$_['text_column_right']   = 'Column Right';

// Entry
$_['entry_code']          = 'Masukan ID YM Anda :';
$_['entry_layout']        = 'Layout:';
$_['entry_position']      = 'Posisi:';
$_['entry_status']        = 'Status:';
$_['entry_sort_order']    = 'Urutan:';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify module YM Indicator!';
$_['error_code']          = 'Code Required';
?>